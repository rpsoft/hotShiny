# Main App Function
# Entry point for hotShiny applications

# Helper functions to get R6 classes from namespace
# These ensure classes are accessible even if not explicitly exported
.get_graph_builder_class <- function() {
  tryCatch({
    utils::getFromNamespace("GraphBuilder", "hotShiny")
  }, error = function(e) {
    # Fallback: class should be in namespace, try direct access
    ns <- asNamespace("hotShiny")
    if (exists("GraphBuilder", envir = ns)) {
      get("GraphBuilder", envir = ns)
    } else {
      stop("GraphBuilder class not found in package namespace. Package may need to be rebuilt.")
    }
  })
}

.get_state_manager_class <- function() {
  tryCatch({
    utils::getFromNamespace("StateManager", "hotShiny")
  }, error = function(e) {
    ns <- asNamespace("hotShiny")
    if (exists("StateManager", envir = ns)) {
      get("StateManager", envir = ns)
    } else {
      stop("StateManager class not found in package namespace.")
    }
  })
}

.get_executor_class <- function() {
  tryCatch({
    utils::getFromNamespace("ReactiveExecutor", "hotShiny")
  }, error = function(e) {
    ns <- asNamespace("hotShiny")
    if (exists("ReactiveExecutor", envir = ns)) {
      get("ReactiveExecutor", envir = ns)
    } else {
      stop("ReactiveExecutor class not found in package namespace.")
    }
  })
}

.get_app_class <- function() {
  # HotShinyApp is in this file, should always be available
  HotShinyApp
}

#' Create a hotShiny application
#'
#' @param ui UI function or object
#' @param server Server function
#' @param ... Additional arguments
#' @return App object
app <- function(ui, server, ...) {
  # Create graph builder (get class and instantiate)
  GraphBuilderClass <- .get_graph_builder_class()
  builder <- GraphBuilderClass$new()
  set_graph_builder(builder)
  
  # Create state manager
  StateManagerClass <- .get_state_manager_class()
  state_manager <- StateManagerClass$new()
  
  # Build graph from server function
  # This will happen as reactive(), observe(), etc. are called
  graph <- builder$get_graph()
  
  # Create executor
  ExecutorClass <- .get_executor_class()
  executor <- ExecutorClass$new(graph, state_manager)
  set_executor(executor)
  
  # Create app object
  AppClass <- .get_app_class()
  app_obj <- AppClass$new(
    ui = ui,
    server = server,
    builder = builder,
    executor = executor,
    state_manager = state_manager,
    ...
  )
  
  app_obj
}

#' HotShiny App
#'
#' Main application object
HotShinyApp <- R6::R6Class("HotShinyApp",
  public = list(
    ui = NULL,
    server = NULL,
    builder = NULL,
    executor = NULL,
    state_manager = NULL,
    server_func = NULL,
    running = NULL,
    
    initialize = function(ui, server, builder, executor, state_manager, ...) {
      self$ui <- ui
      self$server <- server
      self$builder <- builder
      self$executor <- executor
      self$state_manager <- state_manager
      self$running <- FALSE
      
      # Store server function for later execution
      self$server_func <- server
    },
    
    # Run the app
    runApp = function(host = "127.0.0.1", port = 3838, ...) {
      self$running <- TRUE
      
      # Execute server function to build graph
      # This will call reactive(), observe(), etc.
      tryCatch({
        # Create input and output proxies
        input <- InputProxy$new(builder = self$builder)
        output <- OutputProxy$new(builder = self$builder)
        session <- NULL  # Would create session object
        
        # Call server function
        if (is.function(self$server)) {
          self$server(input, output, session)
        }
      }, finally = {
        # Clean up context
        # set_graph_builder(NULL)
        # set_executor(NULL)
      })
      
      # Start HTTP server (would use httpuv)
      # For now, just return
      message("App would run on http://", host, ":", port)
      
      self
    },
    
    # Get graph
    get_graph = function() {
      self$builder$get_graph()
    },
    
    # Get executor
    get_executor = function() {
      self$executor
    },
    
    # Get state manager
    get_state_manager = function() {
      self$state_manager
    }
  )
)
