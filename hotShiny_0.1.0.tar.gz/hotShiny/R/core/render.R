# Render Functions Implementation
# Reimplements render*() functions to build graph

#' Render text output
#'
#' @param expr Expression to render
#' @param env Environment
#' @param quoted Whether expression is quoted
#' @param outputArgs Output arguments
#' @param ... Additional arguments
renderText <- function(expr, env = parent.frame(), quoted = FALSE,
                      outputArgs = list(), ...) {
  render_impl("text", expr, env, quoted, outputArgs, ...)
}

#' Render plot output
#'
#' @param expr Expression to render
#' @param env Environment
#' @param quoted Whether expression is quoted
#' @param width Width
#' @param height Height
#' @param ... Additional arguments
renderPlot <- function(expr, env = parent.frame(), quoted = FALSE,
                      width = "auto", height = "auto", ...) {
  render_impl("plot", expr, env, quoted, list(width = width, height = height), ...)
}

#' Render table output
#'
#' @param expr Expression to render
#' @param env Environment
#' @param quoted Whether expression is quoted
#' @param ... Additional arguments
renderTable <- function(expr, env = parent.frame(), quoted = FALSE, ...) {
  render_impl("table", expr, env, quoted, list(), ...)
}

#' Render data table output
#'
#' @param expr Expression to render
#' @param env Environment
#' @param quoted Whether expression is quoted
#' @param ... Additional arguments
renderDataTable <- function(expr, env = parent.frame(), quoted = FALSE, ...) {
  render_impl("datatable", expr, env, quoted, list(), ...)
}

#' Render UI output
#'
#' @param expr Expression to render
#' @param env Environment
#' @param quoted Whether expression is quoted
#' @param ... Additional arguments
renderUI <- function(expr, env = parent.frame(), quoted = FALSE, ...) {
  render_impl("ui", expr, env, quoted, list(), ...)
}

#' Generic render implementation
#'
#' @param render_type Type of render function
#' @param expr Expression to render
#' @param env Environment
#' @param quoted Whether expression is quoted
#' @param outputArgs Output arguments
#' @param ... Additional arguments
render_impl <- function(render_type, expr, env, quoted, outputArgs, ...) {
  builder <- get_graph_builder()
  
  if (is.null(builder)) {
    stop("render functions must be called within a hotShiny app context")
  }
  
  # Get the expression
  if (!quoted) {
    expr <- rlang::enquo(expr)
  }
  expr_ast <- rlang::get_expr(expr)
  
  # Extract dependencies
  deps <- extract_dependencies(expr_ast)
  
  # Get output name from context (would be set by output$x <- render*())
  output_name <- get_current_output_name()
  
  if (is.null(output_name)) {
    stop("render functions must be assigned to output$x")
  }
  
  source <- get_source_location()
  
  # Register render node
  node <- builder$register_render(
    render_type = render_type,
    output_name = output_name,
    expr = expr_ast,
    deps = deps,
    source = source
  )
  
  # Return render proxy
  RenderProxy$new(node_id = node$id, render_type = render_type, builder = builder)
}

#' Render Proxy
#'
#' Proxy object for render functions
RenderProxy <- R6::R6Class("RenderProxy",
  public = list(
    node_id = NULL,
    render_type = NULL,
    builder = NULL,
    
    initialize = function(node_id, render_type, builder) {
      self$node_id <- node_id
      self$render_type <- render_type
      self$builder <- builder
    }
  )
)

# Context for tracking current output assignment
output_assignment_context <- new.env(parent = emptyenv())

#' Set current output name (called during output$x <- assignment)
#'
#' @param name Output name
set_current_output_name <- function(name) {
  assign("current_output", name, envir = output_assignment_context)
}

#' Get current output name
#'
#' @return Output name or NULL
get_current_output_name <- function() {
  get("current_output", envir = output_assignment_context, inherits = FALSE)
}

#' Clear current output name
clear_current_output_name <- function() {
  if (exists("current_output", envir = output_assignment_context)) {
    rm("current_output", envir = output_assignment_context)
  }
}
