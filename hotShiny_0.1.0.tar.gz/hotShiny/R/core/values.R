# Reactive Values Implementation
# Reimplements reactiveValues() to build graph

#' Create reactive values
#'
#' @param ... Named values
#' @return ReactiveValues object
reactiveValues <- function(...) {
  builder <- get_graph_builder()
  
  if (is.null(builder)) {
    stop("reactiveValues() must be called within a hotShiny app context")
  }
  
  values <- list(...)
  rv <- ReactiveValues$new(builder = builder)
  
  # Initialize with provided values
  for (name in names(values)) {
    rv[[name]] <- values[[name]]
  }
  
  rv
}

#' Reactive Values
#'
#' Container for reactive values (like Shiny's reactiveValues)
ReactiveValues <- R6::R6Class("ReactiveValues",
  public = list(
    values = NULL,
    builder = NULL,
    node_ids = NULL,
    
    initialize = function(builder) {
      self$values <- new.env(parent = emptyenv())
      self$builder <- builder
      self$node_ids <- new.env(parent = emptyenv())
    },
    
    # Get a value
    get = function(name) {
      if (exists(name, envir = self$values)) {
        get(name, envir = self$values)
      } else {
        NULL
      }
    },
    
    # Set a value
    set = function(name, value) {
      assign(name, value, envir = self$values)
      
      # Register as input node if not exists
      node_id <- paste0("reactiveValues.", name)
      if (!exists(name, envir = self$node_ids)) {
        # Create input-like node for this value
        input_node <- builder$register_input(name, source = get_source_location())
        assign(name, input_node$id, envir = self$node_ids)
      }
    },
    
    # Get all names
    names = function() {
      ls(envir = self$values)
    },
    
    # Get all values as list
    to_list = function() {
      as.list(self$values)
    }
  ),
  
  active = list(
    # Allow $ access
    `$` = function(x) {
      if (missing(x)) {
        return(self)
      }
      self$get(x)
    }
  )
)

# Make ReactiveValues work with $ and [[
`$.ReactiveValues` <- function(x, name) {
  x$get(name)
}

`$<-.ReactiveValues` <- function(x, name, value) {
  x$set(name, value)
  x
}

`[[.ReactiveValues` <- function(x, i, ...) {
  x$get(i)
}

`[[<-.ReactiveValues` <- function(x, i, ..., value) {
  x$set(i, value)
  x
}

# Input object (for input$x access)
InputProxy <- R6::R6Class("InputProxy",
  public = list(
    builder = NULL,
    
    initialize = function(builder) {
      self$builder <- builder
    },
    
    # Get input value by name
    get = function(name) {
      # Register input node
      if (!is.null(self$builder)) {
        node <- self$builder$register_input(name)
        # Get value from executor
        executor <- get_executor()
        if (!is.null(executor)) {
          executor$get_value(node$id)
        } else {
          NULL
        }
      } else {
        NULL
      }
    }
  )
)

# Make InputProxy work with $
`$.InputProxy` <- function(x, name) {
  x$get(name)
}

# Output object (for output$x <- assignment)
OutputProxy <- R6::R6Class("OutputProxy",
  public = list(
    builder = NULL,
    
    initialize = function(builder) {
      self$builder <- builder
    },
    
    # Set output (called during output$x <- render*())
    set = function(name, value) {
      set_current_output_name(name)
      # The render function will pick this up
      # Then clear it
      on.exit(clear_current_output_name())
      
      # Store the render proxy
      # This will be handled by the render function
      value
    }
  )
)

# Make OutputProxy work with $<-
`$<-.OutputProxy` <- function(x, name, value) {
  set_current_output_name(name)
  on.exit(clear_current_output_name())
  value
}
