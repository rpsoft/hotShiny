# Graph Builder
# Transforms Shiny code into reactive graph IR

#' Reactive Graph
#'
#' Container for the reactive graph structure
ReactiveGraph <- R6::R6Class("ReactiveGraph",
  public = list(
    nodes = NULL,  # Named list of nodes (id -> node)
    edges = NULL,  # List of edges (from -> to)
    version = NULL,
    
    initialize = function(version = 1L) {
      self$nodes <- new.env(parent = emptyenv())
      self$edges <- list()
      self$version <- version
    },
    
    # Add a node to the graph
    add_node = function(node) {
      self$nodes[[node$id]] <- node
      # Add edges for dependencies
      for (dep_id in node$deps) {
        self$edges <- c(self$edges, list(list(from = dep_id, to = node$id)))
      }
    },
    
    # Get a node by ID
    get_node = function(id) {
      self$nodes[[id]]
    },
    
    # Get all nodes
    get_all_nodes = function() {
      as.list(self$nodes)
    },
    
    # Get nodes of a specific type
    get_nodes_by_type = function(type) {
      Filter(function(n) n$type == type, self$get_all_nodes())
    },
    
    # Serialize graph to list (for JSON)
    to_list = function() {
      list(
        version = self$version,
        nodes = lapply(self$get_all_nodes(), function(n) n$to_list()),
        edges = self$edges
      )
    },
    
    # Get topological sort of nodes (for execution order)
    topological_sort = function() {
      # Build adjacency list
      adj <- new.env(parent = emptyenv())
      in_degree <- new.env(parent = emptyenv())
      
      all_nodes <- self$get_all_nodes()
      
      # Initialize
      for (node in all_nodes) {
        assign(node$id, list(), envir = adj)
        assign(node$id, 0L, envir = in_degree)
      }
      
      # Build graph
      for (edge in self$edges) {
        from <- edge$from
        to <- edge$to
        
        # Add edge
        adj_list <- get(from, envir = adj, inherits = FALSE)
        adj_list <- c(adj_list, list(to))
        assign(from, adj_list, envir = adj)
        
        # Increment in-degree
        deg <- get(to, envir = in_degree, inherits = FALSE)
        assign(to, deg + 1L, envir = in_degree)
      }
      
      # Kahn's algorithm
      queue <- list()
      result <- list()
      
      # Find nodes with in-degree 0
      for (node in all_nodes) {
        if (get(node$id, envir = in_degree, inherits = FALSE) == 0L) {
          queue <- c(queue, list(node$id))
        }
      }
      
      while (length(queue) > 0) {
        current <- queue[[1]]
        queue <- queue[-1]
        result <- c(result, list(current))
        
        # Process neighbors
        neighbors <- get(current, envir = adj, inherits = FALSE)
        for (neighbor in neighbors) {
          deg <- get(neighbor, envir = in_degree, inherits = FALSE)
          assign(neighbor, deg - 1L, envir = in_degree)
          if (get(neighbor, envir = in_degree, inherits = FALSE) == 0L) {
            queue <- c(queue, list(neighbor))
          }
        }
      }
      
      # Check for cycles
      if (length(result) != length(all_nodes)) {
        warning("Graph contains cycles - topological sort incomplete")
      }
      
      result
    }
  )
)

#' Graph Builder
#'
#' Builds reactive graph from Shiny code
GraphBuilder <- R6::R6Class("GraphBuilder",
  public = list(
    graph = NULL,
    reactive_context = NULL,  # Track reactive sources
    
    initialize = function() {
      self$graph <- ReactiveGraph$new()
      self$reactive_context <- new.env(parent = emptyenv())
      self$reactive_context$reactive_sources <- new.env(parent = emptyenv())
    },
    
    # Build graph from server function
    build_from_server = function(server_func, source_info = NULL) {
      # Capture the server function's body
      body_expr <- body(server_func)
      
      # Create a new environment to track reactive declarations
      tracking_env <- new.env(parent = environment(server_func))
      
      # We'll need to intercept reactive declarations
      # This is complex - we'll use a combination of:
      # 1. AST analysis
      # 2. Runtime interception (via modified functions)
      
      # For now, return the graph structure
      # The actual building will happen as reactive() etc. are called
      self$graph
    },
    
    # Register an input node
    register_input = function(input_name, source = NULL) {
      node_id <- paste0("input.", input_name)
      
      # Check if already exists
      if (!is.null(self$graph$get_node(node_id))) {
        return(self$graph$get_node(node_id))
      }
      
      node <- InputNode$new(
        id = node_id,
        input_name = input_name,
        source = source
      )
      
      self$graph$add_node(node)
      node
    },
    
    # Register a reactive expression
    register_reactive = function(expr, name = NULL, deps = NULL, source = NULL) {
      # Extract dependencies if not provided
      if (is.null(deps)) {
        deps <- extract_dependencies(expr)
      }
      
      # Convert expression to AST
      expr_ast <- expr_to_ast(expr)
      
      node_id <- new_node_id("reactive")
      node <- ReactiveExprNode$new(
        id = node_id,
        deps = deps,
        expr = expr_ast,
        name = name,
        source = source
      )
      
      self$graph$add_node(node)
      
      # Track as reactive source if named
      if (!is.null(name)) {
        self$reactive_context$reactive_sources[[name]] <- node_id
      }
      
      node
    },
    
    # Register an observer
    register_observer = function(expr, deps = NULL, priority = 0L, 
                                 once = FALSE, suspended = FALSE, source = NULL) {
      if (is.null(deps)) {
        deps <- extract_dependencies(expr)
      }
      
      expr_ast <- expr_to_ast(expr)
      
      node_id <- new_node_id("observe")
      node <- ObserverNode$new(
        id = node_id,
        deps = deps,
        expr = expr_ast,
        priority = priority,
        once = once,
        suspended = suspended,
        source = source
      )
      
      self$graph$add_node(node)
      node
    },
    
    # Register a render function
    register_render = function(render_type, output_name, expr, deps = NULL, source = NULL) {
      if (is.null(deps)) {
        deps <- extract_dependencies(expr)
      }
      
      expr_ast <- expr_to_ast(expr)
      
      node_id <- new_node_id("render")
      node <- RenderNode$new(
        id = node_id,
        render_type = render_type,
        output_name = output_name,
        deps = deps,
        expr = expr_ast,
        source = source
      )
      
      self$graph$add_node(node)
      
      # Also create output node
      output_node_id <- paste0("output.", output_name)
      output_node <- OutputNode$new(
        id = output_node_id,
        output_name = output_name,
        render_type = render_type,
        deps = list(node_id),
        source = source
      )
      self$graph$add_node(output_node)
      
      node
    },
    
    # Get the current graph
    get_graph = function() {
      self$graph
    }
  )
)

#' Build reactive graph from server function
#'
#' @param server_func Server function
#' @param source_info Source file information
#' @return ReactiveGraph
build_reactive_graph <- function(server_func, source_info = NULL) {
  builder <- GraphBuilder$new()
  builder$build_from_server(server_func, source_info)
  builder$get_graph()
}
