# Runtime Executor
# Executes the reactive graph

#' Reactive Executor
#'
#' Executes reactive graph nodes in correct order
ReactiveExecutor <- R6::R6Class("ReactiveExecutor",
  public = list(
    graph = NULL,
    state_manager = NULL,
    execution_env = NULL,
    
    initialize = function(graph, state_manager = NULL) {
      self$graph <- graph
      self$state_manager <- if (is.null(state_manager)) StateManager$new() else state_manager
      self$execution_env <- new.env(parent = .GlobalEnv)
    },
    
    # Execute the graph
    execute = function() {
      # Get topological sort
      execution_order <- self$graph$topological_sort()
      
      # Execute nodes in order
      for (node_id in execution_order) {
        node <- self$graph$get_node(node_id)
        if (is.null(node)) next
        
        # Check if node is dirty or needs execution
        if (self$should_execute(node)) {
          self$execute_node(node)
        }
      }
      
      # Clear dirty flags
      self$state_manager$clear_all_dirty()
    },
    
    # Check if node should be executed
    should_execute = function(node) {
      # Always execute if dirty
      if (self$state_manager$is_dirty(node$id)) {
        return(TRUE)
      }
      
      # Check if any dependency is dirty
      for (dep_id in node$deps) {
        if (self$state_manager$is_dirty(dep_id)) {
          return(TRUE)
        }
      }
      
      # For observers, check if they need to run
      if (inherits(node, "ObserverNode")) {
        destroyed <- if (is.null(node$metadata$destroyed)) FALSE else node$metadata$destroyed
        if (!node$suspended && !destroyed) {
          # Check if dependencies changed
          return(any(vapply(node$deps, function(d) {
            self$state_manager$is_dirty(d)
          }, logical(1))))
        }
      }
      
      FALSE
    },
    
    # Execute a single node
    execute_node = function(node) {
      tryCatch({
        self$state_manager$set_execution_state(node$id, "executing")
        
        value <- switch(node$type,
          "input" = {
            # Input nodes are set externally
            self$state_manager$get_value(node$id)
          },
          "reactive" = {
            self$execute_reactive(node)
          },
          "observe" = {
            self$execute_observer(node)
            NULL  # Observers don't return values
          },
          "render" = {
            self$execute_render(node)
          },
          "output" = {
            # Output nodes get values from render nodes
            self$state_manager$get_value(node$id)
          },
          {
            warning("Unknown node type: ", node$type)
            NULL
          }
        )
        
        # Store value if not NULL
        if (!is.null(value)) {
          self$state_manager$set_value(node$id, value)
        }
        
        # Mark as clean
        self$state_manager$clear_dirty(node$id)
        self$state_manager$set_execution_state(node$id, "completed")
        
      }, error = function(e) {
        self$state_manager$set_execution_state(node$id, list(
          status = "error",
          error = conditionMessage(e)
        ))
        warning("Error executing node ", node$id, ": ", conditionMessage(e))
      })
    },
    
    # Execute a reactive expression
    execute_reactive = function(node) {
      if (is.null(node$expr)) {
        return(NULL)
      }
      
      # Reconstruct expression from AST
      expr <- ast_to_expr(node$expr)
      
      # Get dependency values
      dep_values <- list()
      for (dep_id in node$deps) {
        dep_value <- self$get_value(dep_id)
        # Extract name from dep_id (e.g., "input.x" -> "x")
        dep_name <- gsub("^[^.]+\\.", "", dep_id)
        dep_values[[dep_name]] <- dep_value
      }
      
      # Create evaluation environment
      eval_env <- new.env(parent = self$execution_env)
      
      # Add dependency values to environment
      for (name in names(dep_values)) {
        assign(name, dep_values[[name]], envir = eval_env)
      }
      
      # Add input proxy (would get from app context)
      # For now, create a simple proxy
      # input_proxy <- InputProxy$new(builder = self$builder)
      # assign("input", input_proxy, envir = eval_env)
      
      # Evaluate expression
      result <- eval(expr, envir = eval_env)
      result
    },
    
    # Execute an observer
    execute_observer = function(node) {
      if (is.null(node$expr)) {
        return(NULL)
      }
      
      # Check if suspended
      if (node$suspended) {
        return(NULL)
      }
      
      # Check if once and already executed
      executed <- if (is.null(node$metadata$executed)) FALSE else node$metadata$executed
      if (node$once && executed) {
        return(NULL)
      }
      
      # Reconstruct expression
      expr <- ast_to_expr(node$expr)
      
      # Get dependency values
      eval_env <- new.env(parent = self$execution_env)
      
      # Add input proxy (would get from app context)
      # assign("input", input_proxy, envir = eval_env)
      
      # Evaluate (side effects)
      eval(expr, envir = eval_env)
      
      # Mark as executed if once
      if (node$once) {
        node$metadata$executed <- TRUE
      }
      
      NULL
    },
    
    # Execute a render function
    execute_render = function(node) {
      if (is.null(node$expr)) {
        return(NULL)
      }
      
      # Reconstruct expression
      expr <- ast_to_expr(node$expr)
      
      # Get dependency values
      eval_env <- new.env(parent = self$execution_env)
      
      # Add input proxy (would get from app context)
      # assign("input", input_proxy, envir = eval_env)
      
      # Evaluate render expression
      result <- eval(expr, envir = eval_env)
      
      # Format based on render type
      formatted <- switch(node$render_type,
        "text" = as.character(result),
        "plot" = result,  # Would need to convert to base64 or similar
        "table" = result,
        "datatable" = result,
        "ui" = result,
        result
      )
      
      formatted
    },
    
    # Get value for a node (with caching)
    get_value = function(node_id) {
      # Check cache first
      value <- self$state_manager$get_value(node_id)
      if (!is.null(value)) {
        return(value)
      }
      
      # Execute node if needed
      node <- self$graph$get_node(node_id)
      if (!is.null(node)) {
        self$execute_node(node)
        return(self$state_manager$get_value(node_id))
      }
      
      NULL
    },
    
    # Set input value
    set_input = function(input_name, value) {
      node_id <- paste0("input.", input_name)
      self$state_manager$set_value(node_id, value)
      # Trigger execution
      self$execute()
    },
    
    # Get state manager
    get_state_manager = function() {
      self$state_manager
    }
  )
)
