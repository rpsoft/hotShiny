# WebSocket Server
# Handles WebSocket communication with clients

#' WebSocket Message Types
WS_MESSAGE_TYPES <- list(
  GRAPH_UPDATE = "graph_update",
  VALUE_UPDATE = "value_update",
  DOM_PATCH = "dom_patch",
  USER_INPUT = "user_input",
  HOT_RELOAD = "hot_reload",
  ERROR = "error",
  PING = "ping",
  PONG = "pong"
)

#' WebSocket Server
#'
#' Manages WebSocket connections and communication
WebSocketServer <- R6::R6Class("WebSocketServer",
  public = list(
    app = NULL,
    connections = NULL,
    message_handlers = NULL,
    
    initialize = function(app) {
      self$app <- app
      self$connections <- list()
      self$message_handlers <- new.env(parent = emptyenv())
      
      # Register default handlers
      self$register_handler(WS_MESSAGE_TYPES$USER_INPUT, function(msg, ws) {
        self$handle_user_input(msg, ws)
      })
      
      self$register_handler(WS_MESSAGE_TYPES$PING, function(msg, ws) {
        self$send_message(ws, WS_MESSAGE_TYPES$PONG, list())
      })
    },
    
    # Register a message handler
    register_handler = function(message_type, handler) {
      self$message_handlers[[message_type]] <- handler
    },
    
    # Handle new WebSocket connection
    on_open = function(ws) {
      connection_id <- paste0("conn_", length(self$connections) + 1L)
      self$connections[[connection_id]] <- ws
      
      # Send initial graph
      self$send_graph_update(ws)
      
      connection_id
    },
    
    # Handle WebSocket message
    on_message = function(ws, is_binary, message) {
      tryCatch({
        # Parse message
        if (is_binary) {
          # Binary message (would need deserialization)
          # For now, assume JSON
          msg <- jsonlite::fromJSON(rawToChar(message), simplifyVector = FALSE)
        } else {
          msg <- jsonlite::fromJSON(message, simplifyVector = FALSE)
        }
        
        # Get message type
        msg_type <- msg$type
        if (is.null(msg_type)) {
          warning("Message missing type field")
          return(invisible(NULL))
        }
        
        # Find handler
        handler <- self$message_handlers[[msg_type]]
        if (!is.null(handler)) {
          handler(msg, ws)
        } else {
          warning("No handler for message type: ", msg_type)
        }
        
      }, error = function(e) {
        self$send_error(ws, conditionMessage(e))
      })
    },
    
    # Handle WebSocket close
    on_close = function(ws) {
      # Remove connection
      for (i in seq_along(self$connections)) {
        if (identical(self$connections[[i]], ws)) {
          self$connections <- self$connections[-i]
          break
        }
      }
    },
    
    # Send message to a WebSocket connection
    send_message = function(ws, type, data) {
      message <- list(
        type = type,
        data = data,
        timestamp = as.numeric(Sys.time())
      )
      
      json_msg <- jsonlite::toJSON(message, auto_unbox = TRUE)
      
      # Send via httpuv
      # ws$send(json_msg)
      # For now, just return the message
      json_msg
    },
    
    # Send graph update
    send_graph_update = function(ws) {
      graph <- self$app$get_graph()
      graph_json <- serialize_graph(graph)
      graph_data <- jsonlite::fromJSON(graph_json, simplifyVector = FALSE)
      
      self$send_message(ws, WS_MESSAGE_TYPES$GRAPH_UPDATE, graph_data)
    },
    
    # Send value update
    send_value_update = function(node_id, value) {
      update_data <- list(
        node_id = node_id,
        value = value
      )
      
      # Send to all connections
      for (conn in self$connections) {
        self$send_message(conn, WS_MESSAGE_TYPES$VALUE_UPDATE, update_data)
      }
    },
    
    # Send DOM patch
    send_dom_patch = function(patch) {
      # Send to all connections
      for (conn in self$connections) {
        self$send_message(conn, WS_MESSAGE_TYPES$DOM_PATCH, patch)
      }
    },
    
    # Send hot reload notification
    send_hot_reload = function(diff_summary) {
      reload_data <- list(
        summary = diff_summary,
        timestamp = as.numeric(Sys.time())
      )
      
      # Send to all connections
      for (conn in self$connections) {
        self$send_message(conn, WS_MESSAGE_TYPES$HOT_RELOAD, reload_data)
      }
    },
    
    # Send error
    send_error = function(ws, error_message) {
      error_data <- list(
        message = error_message,
        timestamp = as.numeric(Sys.time())
      )
      
      self$send_message(ws, WS_MESSAGE_TYPES$ERROR, error_data)
    },
    
    # Handle user input
    handle_user_input = function(msg, ws) {
      data <- msg$data
      if (is.null(data$input_name) || is.null(data$value)) {
        warning("Invalid user input message")
        return(invisible(NULL))
      }
      
      # Set input value in executor
      executor <- self$app$get_executor()
      if (!is.null(executor)) {
        executor$set_input(data$input_name, data$value)
      }
    },
    
    # Broadcast to all connections
    broadcast = function(type, data) {
      for (conn in self$connections) {
        self$send_message(conn, type, data)
      }
    }
  )
)

#' Create WebSocket server for app
#'
#' @param app HotShinyApp instance
#' @return WebSocketServer instance
create_websocket_server <- function(app) {
  WebSocketServer$new(app)
}
