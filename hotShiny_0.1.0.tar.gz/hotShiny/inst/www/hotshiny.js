/**
 * HotShiny Main Client Library
 * Orchestrates client-side functionality
 */

(function(global) {
  'use strict';
  
  // Import dependencies (would be loaded separately in real implementation)
  // const WebSocketClient = require('./websocket-client.js');
  // const { VirtualDOM, DOMDiff, DOMPatcher } = require('./dom-diff.js');
  // const ReactiveClient = require('./reactive-client.js');
  
  class HotShiny {
    constructor(options = {}) {
      this.options = {
        wsUrl: options.wsUrl || this.getWebSocketUrl(),
        autoConnect: options.autoConnect !== false,
        ...options
      };
      
      this.wsClient = null;
      this.reactiveClient = new ReactiveClient();
      this.domPatcher = null;
      this.initialized = false;
      
      if (this.options.autoConnect) {
        this.init();
      }
    }
    
    init() {
      if (this.initialized) {
        return;
      }
      
      // Initialize WebSocket client
      this.wsClient = new WebSocketClient(this.options.wsUrl);
      
      // Register message handlers
      this.registerMessageHandlers();
      
      // Initialize DOM patcher
      const rootElement = document.getElementById('hotshiny-root') || document.body;
      this.domPatcher = new DOMPatcher(rootElement);
      
      this.initialized = true;
    }
    
    registerMessageHandlers() {
      // Graph update
      this.wsClient.registerHandler('graph_update', (message) => {
        this.reactiveClient.updateGraph(message.data);
        this.handleGraphUpdate(message.data);
      });
      
      // Value update
      this.wsClient.registerHandler('value_update', (message) => {
        const { nodeId, value } = message.data;
        this.reactiveClient.updateValue(nodeId, value);
        this.handleValueUpdate(nodeId, value);
      });
      
      // DOM patch
      this.wsClient.registerHandler('dom_patch', (message) => {
        this.handleDOMPatch(message.data);
      });
      
      // Hot reload
      this.wsClient.registerHandler('hot_reload', (message) => {
        this.handleHotReload(message.data);
      });
      
      // Error
      this.wsClient.registerHandler('error', (message) => {
        console.error('Server error:', message.data.message);
      });
    }
    
    handleGraphUpdate(graphData) {
      // Rebuild UI based on new graph
      // This would involve rendering the UI from the graph structure
      console.log('Graph updated:', graphData);
    }
    
    handleValueUpdate(nodeId, value) {
      // Update UI elements that depend on this value
      const dependents = this.reactiveClient.getDependents(nodeId);
      
      for (let dependentId of dependents) {
        // Trigger re-render of dependent nodes
        this.updateNode(dependentId);
      }
    }
    
    handleDOMPatch(patch) {
      // Apply DOM patch
      if (this.domPatcher) {
        this.domPatcher.patch([patch]);
      }
    }
    
    handleHotReload(reloadData) {
      console.log('Hot reload:', reloadData.summary);
      
      // The graph update will come separately
      // This is just a notification
      this.notifyHotReload(reloadData);
    }
    
    updateNode(nodeId) {
      // Get node value and update corresponding UI element
      const value = this.reactiveClient.getValue(nodeId);
      const node = this.findNodeInGraph(nodeId);
      
      if (node && node.type === 'output') {
        this.updateOutputElement(node.output_name, value);
      }
    }
    
    updateOutputElement(outputName, value) {
      const element = document.getElementById(outputName);
      if (element) {
        // Update element based on render type
        if (element.tagName === 'DIV' || element.tagName === 'SPAN') {
          element.textContent = value;
        } else {
          element.innerHTML = value;
        }
      }
    }
    
    findNodeInGraph(nodeId) {
      if (!this.reactiveClient.graph || !this.reactiveClient.graph.nodes) {
        return null;
      }
      
      return this.reactiveClient.graph.nodes.find(n => n.id === nodeId);
    }
    
    notifyHotReload(reloadData) {
      // Dispatch custom event
      const event = new CustomEvent('hotshiny:reload', {
        detail: reloadData
      });
      document.dispatchEvent(event);
    }
    
    sendInput(inputName, value) {
      if (this.wsClient) {
        this.wsClient.send('user_input', {
          input_name: inputName,
          value: value
        });
      }
    }
    
    getWebSocketUrl() {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const host = window.location.host;
      return `${protocol}//${host}/websocket`;
    }
    
    disconnect() {
      if (this.wsClient) {
        this.wsClient.disconnect();
      }
      this.initialized = false;
    }
  }
  
  // Create global instance
  global.HotShiny = HotShiny;
  
  // Auto-initialize if DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      global.hotShiny = new HotShiny();
    });
  } else {
    global.hotShiny = new HotShiny();
  }
  
})(typeof window !== 'undefined' ? window : this);
