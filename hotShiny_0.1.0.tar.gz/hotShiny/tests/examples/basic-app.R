# Basic Shiny App Example
# Demonstrates basic hotShiny usage

library(hotShiny)

ui <- function() {
  div(
    h1("Basic HotShiny App"),
    textInput("name", "Enter your name:"),
    textOutput("greeting")
  )
}

server <- function(input, output, session) {
  # Reactive expression
  greeting <- reactive({
    paste("Hello,", input$name, "!")
  })
  
  # Render output
  output$greeting <- renderText({
    greeting()
  })
}

# Create and run app
app_obj <- app(ui, server)

# Enable hot reload (in development)
# enable_hot_reload(app_obj)

# Run app
# app_obj$runApp()
